%Copyright, Joshua Finneran, 2021.

%Please cite as: Finneran J, "On the Evaluation of Transport Properties 
%for Droplet Evaporation Problems", International Journal of Heat and Mass
%Transfer, 2021.

%_________________________________________________________________________


run('Input_Parameters.m') % obtain input parameters 
run('Function_Afilm_theoretical.m') %obtains theoretical value of film 
% weighting factor [A_f]_theo from Eq.(44) or Eq.(45)
run('Mesh.m') % constructs 1D mesh

% solution proceeds differently  depending if the surface temperature is 
% specified, or if the steady surface temperature must be found by
% iteration
if strcmp(steady_DropTemp,'yes')
    run('InitialGuess_SteadyDropTemp.m') % initial guess for solution
    run('Solver_FullVarProp_SteadyDropTemp.m') % run iterative solver
    run('Plot_plotfields.m') % plot solution in same style as Fig.6 & 7 in 
    % the accompanying article
elseif strcmp(steady_DropTemp,'no')
    run('InitialGuess_AnyDropTemp.m') % initial guess for solution 
    run('Solver_FullVarProp_AnyDropTemp.m') % run iterative solver
end



