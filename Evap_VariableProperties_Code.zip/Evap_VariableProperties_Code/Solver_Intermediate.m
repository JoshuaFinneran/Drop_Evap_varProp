%Copyright, Joshua Finneran, 2021.

%Please cite as: Finneran J, "On the Evaluation of Transport Properties 
%for Droplet Evaporation Problems", International Journal of Heat and Mass
%Transfer, 2021.

%_________________________________________________________________________


% This code solves for the mass flow (m_dot_FullVarProp) and the temperature
% and mass fraction fields (T and omega) with fully variable properties
% The main loop contains three main sections which correspond to the blocks
% in Fig.2 of the accompanying article

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% initialise convergence creteria
T_change =1;
omega_change = 1;
itt_count =1;

while (T_change > 1e-5 || omega_change > 1e-5) && itt_count < 20

%% Loop to calculate mass flow (m_dot = rho r^2 u) for given Gamma field and given surface omega (omega_s)

m_dot_itt=zeros(2,1);
m_dot_itt(2)= m_dot_FullVarProp;
omega_inf_itt = nan*ones(2,1);
tol=10^-9;
omega_inf_err(2,1) = 1;

%loop varies m_dot until the error in omega_inf is within tolerance
while abs(omega_inf_err(2,1))>tol

    % calculate omega field based on current m_dot best guess
    omega_n(2,1) = omega_s-m_dot_itt(2)*(1-omega_s)*(r_n(1)-r_b(1))/(r_b(1)^2*Gamma_b(1,1));
    for i = 1:N-1
    a = (r_n(i+1)-r_b(i+1))/(r_n(i+1)-r_n(i));
    b = (r_b(i+1)^2*Gamma_b(i+1))/(r_n(i+1)-r_n(i));
    c= (r_b(i+1)-r_n(i))/(r_n(i+1)-r_n(i));
    omega_n(2,i+1) = (m_dot_itt(2)-omega_n(2,i)*(m_dot_itt(2)*a+b))/(m_dot_itt(2)*c-b);
    end
    omega_inf_itt(2,1) = ((r_b(N+1)^2*Gamma_b(N+1)*omega_n(2,N))/(r_b(N+1)-r_n(N))-m_dot_itt(2))/...
        ((r_b(N+1)^2*Gamma_b(N+1))/(r_b(N+1)-r_n(N))-m_dot_itt(2));

    omega_inf_err(2,1) = omega_inf_itt(2,1)-omega_inf; % the error in omega_inf based on current m_dot best guess

    %use Newton-Raphson method to find correct m_dot value
    if isnan(omega_inf_itt(1,1))
        m_dot_itt(1,1) = m_dot_itt(2,1);
        m_dot_itt(2,1)= m_dot_itt(1,1)*1.001;
        omega_inf_itt(1,1)=omega_inf_itt(2,1);
        omega_inf_err(1,1) = omega_inf_err(2,1);
    else
        derr_dM = (omega_inf_err(2,1)-omega_inf_err(1,1))/(m_dot_itt(2,1)-m_dot_itt(1,1));
        m_dot_itt(1,1) = m_dot_itt(2,1);
        m_dot_itt(2,1)= m_dot_itt(1,1) - omega_inf_err(2,1)/derr_dM;
        omega_inf_itt(1,1) = omega_inf_itt(2,1);
        omega_inf_err(1,1) = omega_inf_err(2,1);    
    end

end

omega_b(2,1) = omega_s;
omega_b(2,N+1) = omega_inf;
omega_b(2,2:N) = omega_n(2,1:N-1)+(omega_n(2,2:N)-omega_n(2,1:N-1)).*(r_b(2:N)-r_n(1:N-1))./(r_n(2:N)-r_n(1:N-1));

m_dot_FullVarProp = m_dot_itt(2,1);

%% Solve temperature field for given surface temperature (T_s) and m_dot

% C*T_n=S ---> the equation encodes set of linear equations
C = zeros(N,N);%matrix of coefficients
S=zeros(N,1);%matrix of source terms

C(1,1) = (1/(r_b(2)-r_b(1)))*(r_b(2)^2*lambda_b(2)/(r_n(2)-r_n(1))+r_b(1)^2*lambda_b(1)/(r_n(1)-r_b(1)))  +  m_dot_FullVarProp*cp_A_b(1)/(r_n(1)-r_b(1));
C(1,2) = -(1/(r_b(2)-r_b(1)))*(r_b(2)^2*lambda_b(2)/(r_n(2)-r_n(1)));
S(1,1) = (m_dot_FullVarProp*cp_A_b(1)/(r_n(1)-r_b(1))+(1/(r_b(2)-r_b(1)))*r_b(1)^2*lambda_b(1)/(r_n(1)-r_b(1)))*T_s;
for i=2:N-1
   C(i,i-1) = -(1/(r_b(i+1)-r_b(i)))*r_b(i)^2*lambda_b(i)/(r_n(i)-r_n(i-1)) - m_dot_FullVarProp*cp_A_b(i)/(r_n(i)-r_n(i-1));
   C(i,i) = (1/(r_b(i+1)-r_b(i)))*( r_b(i+1)^2*lambda_b(i+1)/(r_n(i+1)-r_n(i))+r_b(i)^2*lambda_b(i)/(r_n(i)-r_n(i-1)) )... 
             + m_dot_FullVarProp*cp_A_b(i)/(r_n(i)-r_n(i-1));
   C(i,i+1) = -(1/(r_b(i+1)-r_b(i)))*r_b(i+1)^2*lambda_b(i+1)/(r_n(i+1)-r_n(i)); 
end
C(N,N-1) = -(1/(r_b(N+1)-r_b(N)))*r_b(N)^2*lambda_b(N)/(r_n(N)-r_n(N-1)) - m_dot_FullVarProp*cp_A_b(N)/(r_n(N)-r_n(N-1));
C(N,N) = (1/(r_b(N+1)-r_b(N)))*(r_b(N+1)^2*lambda_b(N+1)/(r_b(N+1)-r_n(N))+r_b(N)^2*lambda_b(N)/(r_n(N)-r_n(N-1))) + m_dot_FullVarProp*cp_A_b(N)/(r_n(N)-r_n(N-1)) ;
S(N,1) = (1/(r_b(N+1)-r_b(N)))*(r_b(N+1)^2*lambda_b(N+1)/(r_b(N+1)-r_n(N)))*T_inf;
T_n(2,1:N)=(C\S)';

T_b(2,1) = T_s;
T_b(2,N+1) = T_inf;
T_b(2,2:N) = T_n(2,1:N-1)+(T_n(2,2:N)-T_n(2,1:N-1)).*(r_b(2:N)-r_n(1:N-1))./(r_n(2:N)-r_n(1:N-1));

%% Update fluid property fields

%transport properties
for i=1:N+1
[Gamma_b(i), lambda_b(i), ~]=F_TransportProperties(species_A,species_B,T_b(2,i),omega_b(2,i));
cp_A_b(i) =  F_cp_data(species_A, T_film);
end
%specific heat 
if strcmp(const_SpecificHeat,'yes')
    cp_A_b =  F_cp_data(species_A, T_film)*ones(1,N+1);
else
    for i=1:N+1
    cp_A_b(i) =  Fcp_data(species_A, T_b(2,i));
    end
end


%% calculate the change from last itteration
T_change = sum(abs(T_n(2,1:N)-T_n(1,1:N)))/N;
omega_change = sum(abs(omega_n(2,1:N)-omega_n(1,1:N)))/N;

%% move new guess to old guess
T_n(1,1:N) = T_n(2,1:N);
omega_n(1,1:N) = omega_n(2,1:N);
T_b(1,1:N+1) = T_b(2,1:N+1);
omega_b(1,1:N+1) = omega_b(2,1:N+1);
itt_count = itt_count + 1;

end






