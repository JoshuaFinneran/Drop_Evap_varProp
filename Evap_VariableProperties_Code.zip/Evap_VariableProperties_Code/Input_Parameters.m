%Copyright, Joshua Finneran, 2021.

%Please cite as: Finneran J, "On the Evaluation of Transport Properties 
%for Droplet Evaporation Problems", International Journal of Heat and Mass
%Transfer, 2021.

%_________________________________________________________________________


% far-field boundary conditions
T_inf = 300;           % far-field temperature
omega_inf = 0;          % far-field vapour mass fraction

%droplet size
a_drop = 1; %m

% specify fluids from database 
species_A = 'methane'; % species A is the evaporating liquid
    % valid inputs: 'nitrogen', 'hydrogen', 'methane', 'ethane', 'butane',
    % 'heptane', 'butane'.
species_B = 'air';      % species B is the ambient gas
    % valid inputs: 'air', 'oxygen', 'carbondioxide' 'nitrogen', 
    % 'hydrogen', 'methane', 'ethane', 'butane', 'heptane', 'butane'.

% Function retrieves properties for specified fluid at 1 atm pressure.
% For fluids not in the database, manually input fluid properties.
[M_A, R_A, L, T_BP] = F_fluid_properties(species_A);
    % M_A is the molecular mass of species A 
    % R_A is the specific gas constant of species A
    % L is the latent heat of vaporisation
    % T_BP is the boiling temperature
[M_B, R_B, ~, ~] = F_fluid_properties(species_B);
    % M_B is the molecular mass of species B 
    % R_B is the specific gas constant of species B
    

% is the droplet temperature steady (i.e. at equilibrium/ wet-bulb)? 
steady_DropTemp = 'yes'; %'yes' or 'no'
% droplet temperature
T_s = 0; % K % if steady_DropTemp = 'no', then the droplet temperature must be specified

% is specific heat constant? 
const_SpecificHeat = 'yes';
