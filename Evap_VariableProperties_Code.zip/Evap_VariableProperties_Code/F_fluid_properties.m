function [M, R, L, T_BP] = F_fluid_properties(fluid)

% This function returns fluid properties at atmospheric pressure
    % M is the molecular mass, kg kmol^(-1)
    % R is the specific gas constant, J kg^(-1) K^(-1)
    % L is the latent heat of vaporisation, J kg^(-1)
    % T_BP is the boiling temperature, K

% fluid is a string containing the fluid name. Available fluids:
    %   nitrogen
    %   oxygen (gas only)
    %   air (gas only)
    %   carbondioxide
    %   octane (n-octane)
    %   methane 
    %   hydrogen
    %   heptane (n-heptane)
    %   butane (n-butane)
    %   ethane

% Data from: 
% National Institute of Standards and Technology, NIST Chemistry WebBook, 
% Thermophysical Properties of Fluid Systems, https://webbook.nist.gov/chemistry/fluid/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
M = nan; 
R = nan; 
T_BP = nan;
L = nan;

if strcmp('nitrogen',fluid)
M= 28.013; 
R = 0.2968*1000; 
T_BP = 77.158;
L = 77.158e3-(-122.02e3); 

elseif strcmp('octane',fluid)
M = 114.2; %kg/kmol
R = 8.31446/M*1000; %J/kgK
T_BP = 398.77;
L = 302.2e3; 

elseif strcmp('methane',fluid)
M = 16.04; 
R = 8.31446/M*1000; 
T_BP = 111.67;
L = 510.83e3; 

elseif strcmp('hydrogen',fluid) 
M = 2.01588;
R = 4.1242*1000;
T_BP = 20.369;
L = 448.7e3; 

elseif strcmp('heptane',fluid)
M = 100.2;
R = 8.31446261815324/M*1000;
T_BP = 371.53;
L = 316.88e3; 

elseif strcmp('butane',fluid) %n-butane
M = 58.12;
R = 8.31446261815324/M*1000;
T_BP = 272.66;
L = 584.58e3-198.87e3; 

elseif strcmp('ethane',fluid)
M = 30.0690;
R = 8.31446261815324/M*1000;
T_BP = 184.55;
L = 489.47e3; 

elseif strcmp('air',fluid)
M = 28.97;
R = 8.31446261815324/M*1000;

elseif strcmp('oxygen',fluid)
M = 31.999; 
R = 0.2598*1000;



end

























