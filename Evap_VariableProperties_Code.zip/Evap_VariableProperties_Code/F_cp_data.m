function [cp, cv] = F_cp_data(fluid, T)

% For a given temperature and fluid, this function outputs the gas phase
% specific heat capacity

% Data and polynomial coefficients are from: 
% National Institute of Standards and Technology, NIST Chemistry WebBook, 
% Thermophysical Properties of Fluid Systems, https://webbook.nist.gov/chemistry/fluid/

% fluid is a string containing the fluid name. Available fluids:
    %   nitrogen
    %   oxygen
    %   air
    %   carbondioxide
    %   water
    %   octane (n-octane)
    %   methane
    %   carbonmonoxide
    %   hydrogen
    %   heptane (n-heptane)
    %   butane (n-butane)
    %   ethane
% T is the temperature in Kelvin
% cp is the constant pressure specific heat in J kg^-1 K^-1
% cv is the constant volume specific heat in J kg^-1 K^-1

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

t = T/1000;

if strcmp('nitrogen',fluid)
    M_N2 = 28.013; % molecular mass kg kmol^-1
    R_N2 = 0.2968; % gas constant kJ kg^-1 K^-1
    if T < 500
    A = 28.98641; B = 1.853978; C = -9.647459; D = 16.63537;
    E = 0.000117; F = -8.671914; G = 226.4168; H = 0.0;
    elseif T < 2000
    A = 19.50583; B = 19.88705; C = -8.598535; D = 1.369784;
    E = 0.527601; F = -4.935202; G = 212.3900; H = 0.0;
    elseif T < 6000
    A = 35.51872; B = 1.128728; C = -0.196103; D = 0.014662;
    E = -4.553760; F = -18.97091; G = 224.9810; H = 0.0;
    end		
    cp_N2 = (A + B*t + C*t^2 + D*t^3 + E/t^2);
    cp_N2 = cp_N2/M_N2; 
    cv_N2 = -(R_N2 - cp_N2); 
    cp = cp_N2;
    cv = cv_N2;

elseif strcmp('oxygen',fluid)
    M_O2 = 31.999; 
    R_O2 = 0.2598; 
    if T<700    
    A = 31.32234; B = -20.23531;   C = 57.86644;   D = -36.50624;
    E = -0.007374;  F = -8.903471; G = 246.7945;   H = 0;
    elseif T<2000
    A = 30.03235; B = 8.772972; C = -3.988133; D = 0.788313;
    E = -0.741599; F = -11.32468; G = 236.1663; H = 0;
    elseif T<6000
    A = 20.91111; B = 10.72071; C =	-2.020498; D =	0.146449;
    E =	9.245722; F =	5.337651;  G =	237.6185; H = 0;
    end
    cp_O2 = (A + B*t + C*t^2 + D*t^3 + E/t^2); 
    cp_O2 = cp_O2/M_O2; 
    cv_O2 = -(R_O2 - cp_O2); 
    cp = cp_O2;
    cv = cv_O2;

elseif strcmp('air',fluid)
    M_N2 = 28.013;
    R_N2 = 0.2968; 
    if T < 500
    A = 28.98641; B = 1.853978; C = -9.647459; D = 16.63537;
    E = 0.000117; F = -8.671914; G = 226.4168; H = 0.0;
    elseif T < 2000
    A = 19.50583; B = 19.88705; C = -8.598535; D = 1.369784;
    E = 0.527601; F = -4.935202; G = 212.3900; H = 0.0;
    elseif T < 6000
    A = 35.51872; B = 1.128728; C = -0.196103; D = 0.014662;
    E = -4.553760; F = -18.97091; G = 224.9810; H = 0.0;
    end			
    cp_N2 = (A + B*t + C*t^2 + D*t^3 + E/t^2); %kJ/kmolK
    cp_N2 = cp_N2/M_N2; %kJ/kgK
    cv_N2 = -(R_N2 - cp_N2); %kJ/kgK

    M_O2 = 31.999; %kg/kmol
    R_O2 = 0.2598; %kJ/kgK
    if T<700    
    A = 31.32234; B = -20.23531;   C = 57.86644;   D = -36.50624;
    E = -0.007374;  F = -8.903471; G = 246.7945;   H = 0;
    elseif T<2000
    A = 30.03235; B = 8.772972; C = -3.988133; D = 0.788313;
    E = -0.741599; F = -11.32468; G = 236.1663; H = 0;
    elseif T<6000
    A = 20.91111; B = 10.72071; C =	-2.020498; D =	0.146449;
    E =	9.245722; F =	5.337651;  G =	237.6185; H = 0;
    end
    cp_O2 = (A + B*t + C*t^2 + D*t^3 + E/t^2); 
    H_O2 =  (A*t + B*t^2/2 + C*t^3/3 + D*t^4/4 - E/t + F - H);
    cp_O2 = cp_O2/M_O2;
    H_O2 = H_O2*1000/M_O2;  
    cv_O2 = -(R_O2 - cp_O2);

    omega_N2 = 0.79*M_N2/(0.79*M_N2+0.21*M_O2);
    omega_O2 = 0.21*M_O2/(0.79*M_N2+0.21*M_O2);
    cp = omega_N2*cp_N2 + omega_O2*cp_O2;
    cv = omega_N2*cv_N2 + omega_O2*cv_O2; 


elseif strcmp('carbondioxide',fluid)
    M_CO2 = 44.01; 
    R_CO2 = 0.1889;

    if T<1000
    cp_CO2 = R_CO2*(2.4008 + 0.87351e-2*T - 0.66071e-5*T^2 + 0.20022e-8*T^3 + 0.63274e-15*T^4); %kJ/kgK
    H_CO2 = R_CO2*(2.4008*T + 0.87351e-2/2*T^2 - 0.66071e-5/3*T^3 + 0.20022e-8/4*T^4 + 0.63274e-15/5*T^5 - 0.48378e5); %kJ/kg
    else
    cp_CO2 = R_CO2*(4.4608 + 0.30982e-2*T - 0.12393e-5*T^2 + 0.22741e-9*T^3 - 0.15526e-13*T^4); %kJ/kgK
    H_CO2 = R_CO2*(4.4608*T + 0.30982e-2/2*T^2 - 0.12393e-5/3*T^3 + 0.22741e-9/4*T^4 - 0.15526e-13/5*T^5 - 0.48961e5); %kJ/kg
    end
    cv_CO2 = -(R_CO2 - cp_CO2); 
    cp = cp_CO2;
    cv = cv_CO2;

elseif strcmp('water',fluid)
    M_H2O = 18.015; 
    R_H2O = 0.4615;
    if T<1000
    cp_H2O = R_H2O*(4.0701 - 0.11084e-2*T + 0.41521e-5*T^2 - 0.29637e-8*T^3 + 0.80702e-12*T^4);%kJ/kgK
    H_H2O = R_H2O*(4.0701*T - 0.11084e-2/2*T^2 + 0.41521e-5/3*T^3 - 0.29637e-8/4*T^4 + 0.80702e-12/5*T^5 - 0.3028e5);%kJ/kg
    else
    cp_H2O = R_H2O*(2.7168 + 0.29451e-2*T - 0.80224e-6*T^2 + 0.10227e-9*T^3 - 0.48472e-14*T^4);%kJ/kgK
    H_H2O = R_H2O*(2.7168*T + 0.29451e-2/2*T^2 - 0.80224e-6/3*T^3 + 0.10227e-9/4*T^4 - 0.48472e-14/5*T^5 - 0.29906e5);%kJ/kg
    end
    cv_H2O = -(R_H2O - cp_H2O); %kJ/kgK
    cp = cp_H2O;
    cv = cv_H2O;

elseif strcmp('octane',fluid)
    M_f = 114.2; %kg/kmol
    R_f = 8.31446/M_f; %kJ/kgK
    cp_f = -0.55313 + 181.62*t - 97.787*t^2 + 20.402*t^3 -0.03095/t^2; %cal/gmolK
    cp_f = cp_f*4.184/M_f; %kJ/kgK
    H_f = -0.55313*t + 181.62/2*t^2 - 97.787/3*t^3 + 20.402/4*t^4 +0.03095/t -60.751 + 3.7419; %kcal/gmol
    H_f = H_f*4184/M_f;
    cv_f = cp_f - R_f; 
    Hf_f = -208500/M_f;
    U_f = H_f - R_f*T;
    cp = cp_f;
    cv= cv_f;
    
elseif strcmp('methane',fluid)
    M_f = 16.04; %kg/kmol
    R_f = 8.31446/M_f; %kJ/kgK
    if T < 200 
    cp_f_200 = 2.1061;
    cp_f_100 = 2.08;
    m = ((cp_f_200-cp_f_100)/100);
    y_intercept = cp_f_100-m*100;
    cp_f = y_intercept + m*T;
    H_f = -4.7730e+03 - (y_intercept*(250-T)+m/2*(250^2-T^2));
    elseif T < 250 
    cp_f_200 = 2.1061;
    cp_f_250 = 2.1452;
    m = ((cp_f_250-cp_f_200)/50);
    y_intercept = cp_f_200-m*200;
    cp_f = y_intercept + m*T;
    H_f = -4.7730e+03 - (y_intercept*(250-T)+m/2*(250^2-T^2));
    elseif T < 298
    cp_f_250 = 2.1452;
    cp_f_298 = 2.2222;
    m = ((cp_f_298-cp_f_250)/48);
    y_intercept = cp_f_250-m*250;
    cp_f = y_intercept + m*T;
    H_f = -4.6682e+03 - (y_intercept*(298-T)+m/2*(298^2-T^2));
    elseif T < 1300
    A = -0.703029; B = 108.4773; C = -42.52157; D = 5.862788;
    E = 0.678565; F = -76.84376; G = 158.7163; H = -74.87310;
    cp_f = (A + B*t + C*t^2 + D*t^3 + E/t^2); %kJ/kmolK
    H_f =  (A*t + B*t^2/2 + C*t^3/3 + D*t^4/4 - E/t + F); %kJ/molK
    cp_f = cp_f/M_f; %kJ/kgK
    H_f = H_f*1000/M_f; %kJ/kgK
    elseif T < 6000
    A = 85.81217; B = 11.26467; C = -2.114146; D = 0.138190;
    E = -26.42221; F = -153.5327; G = 224.4143; H = -74.87310;
    cp_f = (A + B*t + C*t^2 + D*t^3 + E/t^2); %kJ/kmolK
    H_f =  (A*t + B*t^2/2 + C*t^3/3 + D*t^4/4 - E/t + F); 
    cp_f = cp_f/M_f; %kJ/kgK
    H_f = H_f*1000/M_f; %kJ/kgK
    end
    cv_f = cp_f - R_f; %kJ/kgK
    cp = cp_f;
    cv=cv_f;
    
elseif strcmp('carbonmonoxide',fluid)
    M_CO = 28.0101; %kg/kmol
    R_CO = 0.2968; %kJ/kgK
    if T<1300    
    A = 25.56759; B = 6.096130; C = 4.054656; D = -2.671301;
    E = 0.131021; F = -118.0089; G = 227.3665; H = -110.5271;
    elseif T<6000
    A = 35.15070; B = 1.300095; C = -0.205921; D = 0.013550;
    E = -3.282780; F = -127.8375; G = 231.7120; H = -110.5271;
    end
    cp_CO = (A + B*t + C*t^2 + D*t^3 + E/t^2); %kJ/kmolK
    cp_CO = cp_CO/M_CO; %kJ/kgK

    cv_CO = -(R_CO - cp_CO); %kJ/kgK
    cp = cp_CO;
    cv = cv_CO;

elseif strcmp('hydrogen',fluid) 
    M_H2 = 2.01588; %kg/kmol
    R_H2 = 4.1242; %kJ/kgK
    if T<300
    T_dat = [13.957	33.957	53.957	73.957	93.957	113.96	133.96	153.96	173.96	193.96	213.96	233.96	253.96	273.96	293.96 300]; 
    cp_dat = [10.343	10.315	10.346	10.567	11.028	11.606	12.18	12.685	13.105	13.443	13.711	13.918	14.078	14.198	14.288 14.288]; 
    cp_H2 = interp1(T_dat,cp_dat,T);
    else
    if T<1000    
    A = 33.066178; B = -11.363417; C = 11.432816; D = -2.772874;
    E = -0.158558; F = -9.980797;  G = 172.707974; H = 0;
    elseif T<2500
    A = 18.563083; B = 12.257357; C = -2.859786; D = 0.268238;
    E = 1.977990; F =-1.147438; G = 156.288133; H =0;
    elseif T<6000
    A = 43.413560; B = -4.293079; C = 1.272428; D = -0.096876;
    E = -20.533862; F = -38.515158; G =162.081354; H = 0;
    end
    cp_H2 = (A + B*t + C*t^2 + D*t^3 + E/t^2); %kJ/kmolK
    H_H2 =  (A*t + B*t^2/2 + C*t^3/3 + D*t^4/4 - E/t + F - H); %kJ/molK
    cp_H2 = cp_H2/M_H2; %kJ/kgK
    H_H2 = H_H2*1000/M_H2; %kJ/kgK
    end

    cv_H2 = -(R_H2 - cp_H2); %kJ/kgK
    cp = cp_H2;
    cv = cv_H2;

elseif strcmp('heptane',fluid)
    M_C7 = 100.2;
    R_C7 = 8.31446261815324/M_C7;
    cp_C7_data = [ 1.273952096	1.543313373	1.648702595	1.656487026	2.10239521	2.515868263	2.868662675	3.165169661	3.415668663	3.628642715	3.808183633	3.962674651	4.096307385	4.217365269	4.342714571	4.426147705];
    T_C7_data = [200	273.15	298.15	300	400	500	600	700	800	900	1000	1100	1200	1300	1400	1500];
    cp = interp1(T_C7_data,cp_C7_data,T);
    cv = cp-R_C7;
    
elseif strcmp('butane',fluid) %n-butane
    M_C4 = 58.12;
    R_C4 = 8.31446261815324/M_C4;
    cp_C4_data = [0.655024088	0.952339986	1.158293187	1.315209911	1.588093599	1.694597385	1.702512044	2.146765313	2.557811425	2.912594632	3.217825189	3.482105988	3.711803166	3.911906401	4.086028906	4.237267722	4.369064006	4.48348245	4.583620096 ];
    T_C4_data = [50	100	150	200	273.15	298.15	300	400	500	600	700	800	900	1000	1100	1200	1300	1400	1500];
    cp = interp1(T_C4_data,cp_C4_data,T);
    cv = cp-R_C4;
    
elseif strcmp('ethane',fluid)
    M_C2 = 30.0690;
    R_C2 = 8.31446261815324/M_C2;
    cp_C2_data = [1.187269281	1.406764442	1.745651668	1.752968173	2.176992916	2.592038312	2.966177791	3.297083375	3.58974359	3.848149257	4.07562606	4.275167116	4.449765539	4.602414447	4.735774386	4.852173335	4.95460441	5.044065316	5.122884033	5.192723403	5.25458113	5.30945492	5.358342479	5.401908943	5.441152017	5.47640427	5.508330839	5.536931724	5.563204629	5.587149556	5.608766504  ];
    T_C2_data = [ 100	200	298.15	300	400	500	600	700	800	900	1000	1100	1200	1300	1400	1500	1600	1700	1800	1900	2000	2100	2200	2300	2400	2500	2600	2700	2800	2900	3000  ];
    cp = interp1(T_C2_data,cp_C2_data,T);
    cv = cp-R_C2;
    
end

% convert to J kg^-1 K^-1
cp = cp*1000;
cv= cv*1000;
