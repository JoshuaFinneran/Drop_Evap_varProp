
This code may be used with correct attribution and acknowledgment of the author.
________________________________________________________________________________________________________________________________________________________________

Author: Joshua Finneran, jf721@cam.ac.uk
Date: 09/05/2021

Copyright, Joshua Finneran, 2021.

Description: Code solves the problem of quasi-steady, spherically symmetric, single, pure droplet evaporation in quiescent gas with fully variable transport properties

Please cite as: Finneran J, "On the Evaluation of Transport Properties for Droplet Evaporation Problems", International Journal of Heat and Mass Transfer, 2021.

Recommended software: MATLAB R2017b

________________________________________________________________________________________________________________________________________________________________

Quick Start:

	1. Open 'input_parameters.m', set the desired inputs and save the file.
	2. Open 'RUN_ME.m' and run the code. 

________________________________________________________________________________________________________________________________________________________________

Description of output parameters. The variable names (first item of each line) correspond to MATLAB variables that can be manipulated for data visualisation.

	Results_mainmetrics - an array containg the main numerical outputs
		Results_mainmetrics(1) - j_ev_a_FullVarProp - K_var, evaporation rate with fully variable properties (kg m^-1 s^-1)
		Results_mainmetrics(2) - j_ev_a_theory - K_cst([A_f]_theo), evaporation rate with constant properties evaluated with A_f = [A_f]_theo (kg m^-1 s^-1)
		Results_mainmetrics(3) - j_ev_a_Afilm_onethird - K_cst(1/3), evaporation rate with constant properties evaluated with A_f = 1/3 (kg m^-1 s^-1)
		Results_mainmetrics(4) - j_ev_a_Afilm_half - K_cst(1/2), evaporation rate with constant properties evaluated with A_f = 1/2 (kg m^-1 s^-1)
		Results_mainmetrics(5) - A_film_precise - [A_f]_act, value of film weighting coefficient such that K_cst = K_var
		Results_mainmetrics(6) - A_film_theory - [A_f]_theo, theoretical value of film weighting coefficient (see main article)
		Results_mainmetrics(7) - epsilon_theory_vs_FullVarProp - K_cst([A_f]_theo)/K_var, error from theoretical method
		Results_mainmetrics(8) - epsilon_onethird_vs_FullVarProp - K_cst(1/3)/K_var, error from one-third rule
		Results_mainmetrics(9) - Q_bar_precise - [Q_bar]_var, Droplet heating parameter from fully variable property solution
		Results_mainmetrics(10) - Q_bar_theory - [Q_bar]_cst([A_f]_theo), Droplet heating parameter with constant properties evaluated with A_f = [A_f]_theo
		Results_mainmetrics(11) - Q_bar_Afilm_onethird - [Q_bar]_cst(1/3), Droplet heating parameter with constant properties evaluated with A_f = 1/3
		Results_mainmetrics(12) - Q_bar_Afilm_half - [Q_bar]_cst(1/2), Droplet heating parameter with constant properties evaluated with A_f = 1/2

	Results_fields - stores the resulting temperature, mass fraction, mass diffusivity and thermal conductivity fields (i.e. as function of radius) for
			 various models of transport properties
		Results_fields(1,:) - r - radial distance
		Results_fields(2,:) - T_FullVarProp - temperature field for fully variable property solution (K)
		Results_fields(3,:) - omega_FullVarProp - vapour mass fraction field for fully variable property solution
		Results_fields(4,:) - Gamma_FullVarProp - mass diffusivity field for fully variable property solution (kg m^-1 s^-1)
		Results_fields(5,:) - lambda_FullVarProp - thermal conductivity field for fully variable property solution (W m^-1 K^-1)
		Results_fields(6,:) - T_ConstProp_eq_FullVarProp - temperature field with constant properties such that K_cst = K_var (K) 
		Results_fields(7,:) - omega_ConstProp_eq_FullVarProp - vapour mass fraction field with constant properties such that K_cst = K_var 
		Results_fields(8,:) - Gamma_ConstProp_eq_FullVarProp - mass diffusivity field with constant properties such that K_cst = K_var (kg m^-1 s^-1)
		Results_fields(9,:) - lambda_ConstProp_eq_FullVarProp - thermal conductivity field with constant properties such that K_cst = K_var (W m^-1 K^-1)
		Results_fields(10,:) - T_RootTProp_eq_FullVarProp - temperature field with T^(1/2) model for properties such that K_sqrt = K_var (K)
		Results_fields(11,:) - omega_RootTProp_eq_FullVarProp - vapour mass fraction field with T^(1/2) model for properties such that K_sqrt = K_var
		Results_fields(12,:) - Gamma_RootTProp_eq_FullVarProp - mass diffusivity field with T^(1/2) model for properties such that K_sqrt = K_var (kg m^-1 s^-1)
		Results_fields(13,:) - lambda_RootTProp_eq_FullVarProp - thermal conductivity field with T^(1/2) model for properties such that K_sqrt = K_var (W m^-1 K^-1)
		
	Results_AfilmSweep - stores results with constant properties for a range of values of A_f
		Results_AfilmSweep(1,:) - A_film_vec - contains values of film weighting coefficient A_f
		Results_AfilmSweep(2,:) - j_ev_a_Afilmsweep_vec - K_cst(A_f), evaporation rate as function of A_f (kg m^-1 s^-1)
		Results_AfilmSweep(3,:) - Q_bar_Afilmsweep_vec - [Q_bar]_cst(A_f), droplet heating parameter as function of A_f
		Results_AfilmSweep(4,:) - T_s_Afilmsweep_vec - droplet surface temperature as function of A_f (K)
		Results_AfilmSweep(5,:) - omega_s_Afilmsweep_vec - droplet surface vapour mass fraction as function of A_f
		Results_AfilmSweep(6,:) - Gamma_Afilmsweep_vec - Gamma_f, film mass diffusivity (kg m^-1 s^-1)
		Results_AfilmSweep(1,:) - lambda_Afilmsweep_vec - lambda_f, film thermal conductivity  (W m^-1 K^-1)


________________________________________________________________________________________________________________________________________________________________

Description of files:

	RUN_ME.m	This file should be run by the user to obtain the solution. This code calls the various other files as required.

	Setup files: 
		Input_Parameters.m	Contains the main inputs required. Edit and save this file to change inputs.
		Mesh.m			Constructs the 1D mesh for numerical solution. Sets resolution of radial spatial discretisation. 

	Solver files:
		InitialGuess_AnyDropTemp.m		Produces initial guess for solution with given droplet temperature.
		InitialGuess_SteadyDropTemp.m		Produces initial guess for solution at equilibrium droplet temperature.
		Solver_FullVarProp_AnyDropTemp.m	The solver for the fully variable property solution with given droplet temperature.
		Solver_FullVarProp_SteadyDropTemp.m	The solver for the fully variable property solution at equilibrium droplet temperature.
		Solver_Intermediate.m			This intermediate solver is called by both Solver_FullVarProp_AnyDropTemp.m and Solver_FullVarProp_SteadyDropTemp.m.

	Function files:
		F_cp_data.m			Contains a limited database of specific heat curves as function of temperature.
		F_fluid_properties.m		Contains a limited database of fluid properties.
		F_TransportProperties.m		Calculates transport properties as function of temperature and composition for limited database of fluids.
		F_SpaldingNumbers.m		Calculates the Spalding heat and mass transfer numbers for given fluid properties and ambient conditions.
		Function_Afilm_theoretical.m	Calculates the theoretical film weighting coefficient [A_f]_theo, using Eqs.(43) & (44) from main article.

	Data visualisation:
		Plot_plotfields.m		Plots result in the style of Fig.6 & 7 from the main article 
						[note: only recommended for steady droplet temperature calculations]
		

_____________________________________________________________________________________________________________________________________________________________________

