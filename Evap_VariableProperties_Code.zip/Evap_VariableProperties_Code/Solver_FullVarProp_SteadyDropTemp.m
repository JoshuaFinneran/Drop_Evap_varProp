%Copyright, Joshua Finneran, 2021.

%Please cite as: Finneran J, "On the Evaluation of Transport Properties 
%for Droplet Evaporation Problems", International Journal of Heat and Mass
%Transfer, 2021.

%_________________________________________________________________________


% This numerical solver obtains the quasi-steady single droplet evaporation 
% solution with fully variable transport properties. 

% The surface temperature T_s is calculated such that the droplet is at
% equilibrium temperature (Q_bar = 0).

% To manually replace the transport property function, see the nested
% function '' Solver_intermediate.m ''.


%% Constant property solution as function of A_f, K_cst(A_f)
A_film_vec = 0:0.01:1;
Gamma_Afilmsweep_vec = zeros(1,length(A_film_vec));
lambda_Afilmsweep_vec = zeros(1,length(A_film_vec));
T_s_Afilmsweep_vec = zeros(1,length(A_film_vec));
omega_s_Afilmsweep_vec = zeros(1,length(A_film_vec));
j_ev_a_Afilmsweep_vec = zeros(1,length(A_film_vec));
Q_bar_Afilmsweep_vec = zeros(1,length(A_film_vec));
for i = 1:length(A_film_vec)
T_s_temp = T_BP;
omega_s_temp = omega_inf;
conv = 1;
while conv > 1e-9
    T_film = T_s_temp + A_film_vec(i)*(T_inf-T_s_temp);
    omega_film =  omega_s_temp + A_film_vec(i)*(omega_inf-omega_s_temp);
    
    [Gamma_Afilmsweep_vec(i), lambda_Afilmsweep_vec(i), ~]=F_TransportProperties(species_A,species_B,T_film,omega_film); 
    [cp_A_film, cv_A_film] = F_cp_data(species_A, T_film);
    [cp_B_film, cv_B_film] = F_cp_data(species_B, T_film);
    
    Ja_temp = cp_A_film*T_BP/L;
    gamma_temp = cp_A_film/cv_A_film;
    cp_inf_temp = cp_B_film + omega_inf*(cp_B_film-cp_A_film);
    cp_bar_temp = cp_A_film/cp_inf_temp;
    Le_temp = lambda_Afilmsweep_vec(i)/(cp_inf_temp*Gamma_Afilmsweep_vec(i));
    epsilon = M_A/M_B;
    Phi = 1-omega_inf;
    T_ex = T_inf/T_BP;
    [BM_temp, BT_temp] = F_SpaldingNumbers(Ja_temp, T_ex, Phi, epsilon, Le_temp , gamma_temp, cp_bar_temp);
    
    conv = abs(T_s_temp - (T_inf - BT_temp*L/cp_A_film))/T_s_temp;
    
    T_s_temp = T_inf - BT_temp*L/cp_A_film;
    omega_s_temp = 1 - (1-omega_inf)/(BM_temp+1);
    
    j_ev_a_Afilmsweep_vec(i) = Gamma_Afilmsweep_vec(i)*log(1+BM_temp);
    T_s_Afilmsweep_vec(i) = T_s_temp;
    omega_s_Afilmsweep_vec(i) = omega_s_temp;
end

end

%% Variable property solution

A_film = A_film_theory;
T_film = T_s_theory + A_film*(T_inf-T_s_theory);
A_film_itt(2) = A_film;
tol_A_film = 1e-5;
delta_A_film = 10;
A_film_itt_count = 1;


%this loop iterates A_film at which to evaluate specific heat
while delta_A_film>tol_A_film && A_film_itt_count<10

    [cp_A_film, cv_A_film] = F_cp_data(species_A, T_film);
    [cp_B_film, cv_B_film] = F_cp_data(species_B, T_film);

    %variables with suffix '_itt' contain value from current and previous
    %iteration
    T_s_itt = nan*zeros(2,1); %surface temperature iteration
    T_s_itt(2,1) = T_s;
    omega_s_itt = nan*zeros(2,1); %surface concentration iteration
    omega_s_itt(2,1) = omega_s;

    Q_bar_itt = nan*zeros(2,1); %droplet heating parameter iteration
    Q_bar_itt(2,1) = 20;
    Q_bar_itt_count = 1;
    tol_q = 1e-5; % set convergence tolerance
    
        while abs(Q_bar_itt(2,1))>tol_q && Q_bar_itt_count<50

            relax_factor = 0.9;
            T_s = T_s_itt(2,1);

            %solver produces the mass flow rate (m_dot_FullVarProp) for given
            %surface temperature (T_s)
            run('Solver_Intermediate.m')
            j_ev_FullVarProp = m_dot_FullVarProp/a_drop^2;
            j_ev_a_FullVarProp = j_ev_FullVarProp*a_drop;

            %% calculate energy balance at surface
            % Q_bar_itt is the dimensionless net energy flow out of the droplet
            % Q_bar = q/(j_ev L), where q = -lambda (dT/dr) + j_ev L 
            % Q_bar_itt = 0 for a steady droplet temerature
            % Q_bar_itt > 0 for droplet cooling
            % Q_bar_itt < 0 for droplet heating

            Q_bar_itt(2,1) = -lambda_b(1)*(T_n(2,1)-T_b(2,1))/(r_n(1)-r_b(1))/(j_ev_FullVarProp*L)+1;

            % apply Newton-Raphson method to find surface temperature at which
            % Q_bar = 0
            if isnan(Q_bar_itt(1,1))
                T_s_itt(1,1) = T_s_itt(2,1);
                T_s_itt(2,1)= T_s_itt(1,1)-0.1;
                Q_bar_itt(1,1)=Q_bar_itt(2,1);
            else
                dq_dTs = (Q_bar_itt(2,1)-Q_bar_itt(1,1))/(T_s_itt(2,1)-T_s_itt(1,1));
                T_s_itt(1,1) = T_s_itt(2,1);
                T_s_itt(2,1)= T_s_itt(1,1) - relax_factor*Q_bar_itt(2,1)/dq_dTs;  
                while abs(relax_factor*Q_bar_itt(2,1)/dq_dTs)>T_BP/40 || T_s_itt(2,1)>T_BP || T_s_itt(2,1)<0
                    relax_factor = relax_factor/2;
                    T_s_itt(2,1)= T_s_itt(1,1) - relax_factor*Q_bar_itt(2,1)/dq_dTs;  
                end 
                Q_bar_itt(1,1)=Q_bar_itt(2,1); 
            end

            if abs(Q_bar_itt(2,1))<1e-1
            Q_bar_itt_count = Q_bar_itt_count+1;
            end

            % find surface vapour concentration for given surface temperature
            P_A = exp(L/R_A*(1/T_BP-1/T_s_itt(2,1)));
            omega_s_itt(2,1) = ((1/P_A-1)*M_B/M_A+1)^(-1);
            omega_s = omega_s_itt(2,1);
        end

A_film_precise = interp1(j_ev_a_Afilmsweep_vec,A_film_vec,j_ev_a_FullVarProp);
T_s_temp = interp1(j_ev_a_Afilmsweep_vec,T_s_Afilmsweep_vec,j_ev_a_FullVarProp);
omega_s_temp = interp1(j_ev_a_Afilmsweep_vec,omega_s_Afilmsweep_vec,j_ev_a_FullVarProp);
A_film = A_film_precise;
T_film = T_s_temp + A_film*(T_inf-T_s_temp);
omega_film = omega_s_temp + A_film*(omega_inf-omega_s_temp);

%update specific heat values
[cp_A_film, cv_A_film] = F_cp_data(species_A, T_film);
[cp_B_film, cv_B_film] = F_cp_data(species_B, T_film);

A_film_itt(1) = A_film_itt(2);
A_film_itt(2) = A_film;
delta_A_film = abs(A_film_itt(2)-A_film_itt(1));
A_film_itt_count = A_film_itt_count+1;

end

%end of solution procedure

%% Process outputs

% With the solution obtained, this section processes the outputs

%Fully variable property outputs:
    T_s_FullVarProp = T_s;
    omega_s_FullVarProp = omega_s;
    Q_bar = Q_bar_itt(2);
    r = [r_b(1) r_n r_b(end)];
    T_FullVarProp = [T_s T_n(2,:) T_inf];
    omega_FullVarProp = [omega_s omega_n(2,:) omega_inf];
    Gamma_FullVarProp = zeros(1,length(r));
    lambda_FullVarProp = zeros(1,length(r));
    for i=1:length(r)
    [Gamma_FullVarProp(i), lambda_FullVarProp(i), ~]=F_TransportProperties(species_A,species_B,T_FullVarProp(i),omega_FullVarProp(i));
    end

     
% Find constant properties that give same solution as fully variable
% solution:
    Gamma_film_ConstProp_eq_FullVarProp = j_ev_a_FullVarProp/log((1-omega_inf)/(1-omega_s_FullVarProp));
    lambda_film_ConstProp_eq_FullVarProp = j_ev_a_FullVarProp*cp_A_film/log((cp_A_film/L*(T_inf-T_s_FullVarProp))/(1-Q_bar)+1);

    T_ConstProp_eq_FullVarProp = T_s_FullVarProp + L/cp_A_film*((cp_A_film/L*(T_inf-T_s_FullVarProp)+1-Q_bar)./exp(j_ev_a_FullVarProp*cp_A_film/lambda_film_ConstProp_eq_FullVarProp*a_drop./r) + Q_bar - 1 );
    omega_ConstProp_eq_FullVarProp = 1-(1-omega_inf)./exp(j_ev_a_FullVarProp/Gamma_film_ConstProp_eq_FullVarProp*a_drop./r);
    Gamma_ConstProp_eq_FullVarProp = Gamma_film_ConstProp_eq_FullVarProp*ones(1,length(r));
    lambda_ConstProp_eq_FullVarProp = lambda_film_ConstProp_eq_FullVarProp*ones(1,length(r));

    
%find rootT property solution that gives the same solution as the fully
%variable property solution.
b1 = T_s_FullVarProp/T_inf;
K = -T_s_FullVarProp/T_inf+L/cp_A_film/T_inf*(1-Q_bar);
if K >= 0
    lambda_inf_RootTProp_eq_FullVarProp = j_ev_a_FullVarProp*cp_A_film/2/(1 - b1^0.5 + K^0.5 *(atan((b1/K)^0.5) - atan((1/K)^0.5) ) );   
else
    lambda_inf_RootTProp_eq_FullVarProp = j_ev_a_FullVarProp*cp_A_film/2/(1 - b1^0.5 - K^0.5 *(atan((b1/K)^0.5) - atan((1/K)^0.5) ) );   
end

Gamma_inf_RootTProp_eq_FullVarProp = lambda_inf_RootTProp_eq_FullVarProp/cp_A_film*...
                                    log((cp_A_film/L*(T_inf-T_s_FullVarProp))/(1-Q_bar)+1)/log((1-omega_inf)/(1-omega_s_FullVarProp));
                                
T_interp = T_FullVarProp(1:end-1);
if K >= 0
   int_1 = 1 - (T_interp/T_inf).^0.5 + K^0.5*( atan(((T_interp/T_inf)/K).^0.5)-atan((1/K)^0.5) );
else
   int_1 = 1 - (T_interp/T_inf).^0.5 - K^0.5*( atan(((T_interp/T_inf)/K).^0.5)-atan((1/K)^0.5) );
end

r_interp = j_ev_a_FullVarProp*cp_A_film/(2*lambda_inf_RootTProp_eq_FullVarProp)./int_1;

r_interp(1) = r(1);
T_interp(1) = T_s_FullVarProp;
T_interp(end+1) = T_inf;
r_interp(end+1) = r_interp(end)*10;

T_RootTProp_eq_FullVarProp = interp1(r_interp,T_interp,r);
omega_RootTProp_eq_FullVarProp =1-(1-omega_inf)*((cp_A_film/L*(T_RootTProp_eq_FullVarProp-T_s_FullVarProp)+1-Q_bar)/...
    (cp_A_film/L*(T_inf-T_s_FullVarProp)+1-Q_bar)).^(lambda_inf_RootTProp_eq_FullVarProp/(cp_A_film*Gamma_inf_RootTProp_eq_FullVarProp));

Gamma_RootTProp_eq_FullVarProp = Gamma_inf_RootTProp_eq_FullVarProp*(T_RootTProp_eq_FullVarProp/T_inf).^0.5;
lambda_RootTProp_eq_FullVarProp = lambda_inf_RootTProp_eq_FullVarProp*(T_RootTProp_eq_FullVarProp/T_inf).^0.5;

%% OUTPUTS summary

% j_ev_a is the evaporative mass flux multiplied by droplet radius.
% j_ev_a is equivalent to evaporation rate denoted by K in the main article
j_ev_a_FullVarProp_check = interp1(A_film_vec,j_ev_a_Afilmsweep_vec,A_film_precise); %should equal j_ev_a_FullVarProp
j_ev_a_theory = interp1(A_film_vec,j_ev_a_Afilmsweep_vec,A_film_theory);
j_ev_a_Afilm_onethird = interp1(A_film_vec,j_ev_a_Afilmsweep_vec,1/3);
j_ev_a_Afilm_half = interp1(A_film_vec,j_ev_a_Afilmsweep_vec,1/2);

%epsilon parameters
epsilon_theory_vs_FullVarProp = j_ev_a_theory/j_ev_a_FullVarProp; % [epsilon]^cst_var (A_f = [A_f]_theo)
epsilon_onethird_vs_FullVarProp = j_ev_a_Afilm_onethird/j_ev_a_FullVarProp; % [epsilon]^cst_var (A_f = 1/3)

%percentage error
error_theory_vs_actual = (j_ev_a_theory/j_ev_a_FullVarProp-1)*100; 
error_onethird_vs_actual = (j_ev_a_Afilm_onethird/j_ev_a_FullVarProp-1)*100; 

%vector stores main results
Results_mainmetrics = [j_ev_a_FullVarProp j_ev_a_theory j_ev_a_Afilm_onethird j_ev_a_Afilm_half A_film_precise A_film_theory epsilon_theory_vs_FullVarProp epsilon_onethird_vs_FullVarProp 0 0 0 0];

% Results_fields contains the fields, i.e. how T,omega,lambda and Gamma vary with distance r. 
Results_fields = [r ; ...
    T_FullVarProp ; omega_FullVarProp ; Gamma_FullVarProp ; lambda_FullVarProp ; ...
    T_ConstProp_eq_FullVarProp ; omega_ConstProp_eq_FullVarProp ; Gamma_ConstProp_eq_FullVarProp ; lambda_ConstProp_eq_FullVarProp ; ...
    T_RootTProp_eq_FullVarProp ; omega_RootTProp_eq_FullVarProp ; Gamma_RootTProp_eq_FullVarProp ; lambda_RootTProp_eq_FullVarProp ];

% Results_AfilmSweep stores how the constant property solution varies with
% the choice of A_f
Results_AfilmSweep = [A_film_vec; j_ev_a_Afilmsweep_vec ; Q_bar_Afilmsweep_vec ; T_s_Afilmsweep_vec; omega_s_Afilmsweep_vec;  Gamma_Afilmsweep_vec ; lambda_Afilmsweep_vec];

