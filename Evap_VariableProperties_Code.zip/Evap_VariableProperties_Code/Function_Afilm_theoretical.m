%Copyright, Joshua Finneran, 2021.

%Please cite as: Finneran J, "On the Evaluation of Transport Properties 
%for Droplet Evaporation Problems", International Journal of Heat and Mass
%Transfer, 2021.

%_________________________________________________________________________

% This code obtains theoretical value of the film weighting factor 
% [A_f]_theo from Eq.(44) or Eq.(45) in the accompanying article.

if strcmp(steady_DropTemp,'yes') % solve Eq.(45)

        A_film_theory = 1/3;
        T_s_theory = T_BP;
        omega_s_theory = 0;

        conv = 1;
        while conv > 1e-8

        T_film_theory =T_s_theory+ A_film_theory*(T_inf-T_s_theory);
        omega_film_theory  = omega_s_theory+ A_film_theory*(omega_inf-omega_s_theory);

        [Gamma_film_theory, lambda_film_theory, ~]=F_TransportProperties(species_A,species_B,T_film_theory ,omega_film_theory ); 
        [cp_A_film_theory, cv_A_film_theory] = F_cp_data(species_A, T_film_theory);
        [cp_B_film_theory, cv_B_film_theory] = F_cp_data(species_B, T_film_theory);

        Ja_temp = cp_A_film_theory*T_BP/L;
        gamma_temp = cp_A_film_theory/cv_A_film_theory;
        cp_inf_temp = cp_B_film_theory + omega_inf*(cp_B_film_theory-cp_A_film_theory);
        cp_bar_temp = cp_A_film_theory/cp_inf_temp;
        Le_temp = lambda_film_theory/(cp_inf_temp*Gamma_film_theory);
        epsilon = M_A/M_B;
        Phi = 1-omega_inf;
        T_ex = T_inf/T_BP;
        [BM_temp, BT_temp] = F_SpaldingNumbers(Ja_temp, T_ex, Phi, epsilon, Le_temp , gamma_temp, cp_bar_temp);

        T_s_theory = T_inf - BT_temp*L/cp_A_film_theory;
        omega_s_theory = 1 - (1-omega_inf)/(BM_temp+1);

        delta = (T_inf - T_s_theory)/T_inf;
        zeta = cp_A_film_theory*T_inf/L;
        Lambda = 1/zeta*(1-0) + (delta - 1);
        
        %Eq.(45)
        C1 = 1 - (1-delta)^(1/2) + (2*heaviside(Lambda)-1)*Lambda^(1/2)*(atan(((1-delta)/Lambda)^(1/2))-atan(((1)/Lambda)^(1/2)));
        A_film_theory_2 = ((2*C1/log(delta*zeta/(1-0)+1))^2 - (1-delta))/delta;

        conv = abs(A_film_theory-A_film_theory_2); % measures convergence    
        A_film_theory = A_film_theory_2;

        end

elseif strcmp(steady_DropTemp,'no') % solve Eq.(44)

    T_s_theory   = T_s; 
    omega_s_theory = (M_B/M_A*(exp(L/R_A*(1/T_s_theory - 1/T_BP))-1)+1)^(-1); %Clausius-Clapeyron  
    A_film_theory = 1/3;
    conv = 1;

    while conv > 1e-9
        T_film_theory =T_s_theory+ A_film_theory*(T_inf-T_s_theory);
        omega_film_theory  = omega_s_theory+ A_film_theory*(omega_inf-omega_s_theory); 
        [cp_A_film_theory, cv_A_film_theory] = F_cp_data(species_A, T_film_theory); 
        [Gamma_film_theory, lambda_film_theory, ~]=F_TransportProperties(species_A,species_B,T_film_theory ,omega_film_theory ); 
        
        % Eq. (41)
        Q_bar_theory = 1 - (cp_A_film_theory/L*(T_inf-T_s_theory))/(((1-omega_inf)/(1-omega_s_theory))^(Gamma_film_theory*cp_A_film_theory/lambda_film_theory)-1);

        delta = (T_inf - T_s_theory)/T_inf;
        zeta = cp_A_film_theory*T_inf/L;
        Lambda = 1/zeta*(1-Q_bar_theory) + (delta - 1);
        
        % Eq.(44)
        C1 = 1 - (1-delta)^(1/2) + (2*heaviside(Lambda)-1)*Lambda^(1/2)*(atan(((1-delta)/Lambda)^(1/2))-atan(((1)/Lambda)^(1/2)));
        A_film_theory_2 = ((2*C1/log(delta*zeta/(1-Q_bar_theory)+1))^2 - (1-delta))/delta;

        conv = abs(A_film_theory-A_film_theory_2); 
        A_film_theory = A_film_theory_2;

    end
     
end
