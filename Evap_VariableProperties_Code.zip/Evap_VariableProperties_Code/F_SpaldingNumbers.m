function [BM, BT] = F_SpaldingNumbers(Ja, T_ex, Phi, epsilon, Le, gamma, cp_bar)
%this code is an itterative solver to provide the Spalding mass and heat
%transfer numbers (BM and BT). 
%A Newton�Raphson method with relaxation factors is used to obtain a
%solution
%BM is the Spalding mass transfer number
%BT is the Spalding heat transfer number
%Ja is the Jakob number
%T_ex is the excess temperature ratio
%Phi is the ambient vapour concentration
%epsilon is the maleculate mass ratio
%Le is the Lewis number
%gamma is the vapour specific heat ratio
%cp_bar is the gas species specific heat ratio


tol=10^-10; %the tolerance for convergence of itteration
relax=1; %initial relaxation factor

loop2 = 1;

%check for condense or evaporation
if T_ex>=1
    evap =1;
elseif Phi*epsilon/(exp(gamma/(gamma-1)*(1/(Ja*T_ex)-1/Ja))-1)+Phi-1>0
    evap = 1;
elseif Phi*epsilon/(exp(gamma/(gamma-1)*(1/(Ja*T_ex)-1/Ja))-1)+Phi-1<0
    evap = 0; %will condense
elseif Phi*epsilon/(exp(gamma/(gamma-1)*(1/(Ja*T_ex)-1/Ja))-1)+Phi-1==0
    evap = 2; %equilibrium, air is saturated with vapour
    loop2 = 0;
    BM = 0;
    BT = 0;
end

%provide initial guesses for BT
if evap == 1
if T_ex<1
BT_itt(1) = Ja*T_ex*0.01;
else
    BT_itt(1) = Ja*(T_ex-0.99);
end
elseif evap ==0
    BT_itt(1) = -Ja*T_ex*0.01;
end

%the itteration loop
while loop2 == 1
    
BM_itt(1) = Phi*epsilon/(exp(gamma/(gamma-1)*(1/(Ja*T_ex-BT_itt(1))-1/Ja))-1)+Phi-1;
F(1) = (1+BT_itt(1))^(Le/cp_bar)-(1+BM_itt(1));

BT_itt(2) = BT_itt(1)+0.001;
BM_itt(2) = Phi*epsilon/(exp(gamma/(gamma-1)*(1/(Ja*T_ex-BT_itt(2))-1/Ja))-1)+Phi-1;
F(2) = (1+BT_itt(2))^(Le/cp_bar)-(1+BM_itt(2));

dF_dBT = (F(2)-F(1))/(BT_itt(2)-BT_itt(1));

BT_itt(1) = BT_itt(2);
F(1) = F(2);
loop = 1;
loop1_itt=1;
while loop == 1
BT_itt(2) = BT_itt(1)-relax*F(1)/dF_dBT;
if BT_itt(2)<Ja*(T_ex-1) %if this is true, T_surface > T_BP hence not real it is possible to overshoot T_BP so reduce relaxation factor
    BT_itt(2)=BT_itt(1);
    relax = relax*0.5;
else
BM_itt(2) = Phi*epsilon/(exp(gamma/(gamma-1)*(1/(Ja*T_ex-BT_itt(2))-1/Ja))-1)+Phi-1;
F(2) = (1+BT_itt(2))^(Le/cp_bar)-(1+BM_itt(2));
dF_dBT = (F(2)-F(1))/(BT_itt(2)-BT_itt(1));
BT_itt(1) = BT_itt(2);
F(1) = F(2);
if abs(F(1)) < tol || isnan(dF_dBT)
    loop = 0;
end
end
loop1_itt = loop1_itt+1;
if loop1_itt>1000
   tol =  tol*2;
   loop1_itt=1;
   relax=1;
end
end

%check that turface temperature is less than boiling temperature
BT = BT_itt(2);
BM = BM_itt(2);
clear BT_itt BM_itt F dF_dBT
if imag(BT)~=0
    BT_itt(1) = real(BT);
else
loop2=0;
end



end

if 1/T_ex/(1-BT/(T_ex*Ja))<1
    BT = nan;
    BM = nan;
end

end