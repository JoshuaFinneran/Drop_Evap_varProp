% This creates an initial guess for the mass fraction and temperature
% fields. This is based on assuming constant fluid properties evaluated
% using the 1/3 rule.

% The surface temperature T_s is calculated such that the droplet is at
% equilibrium temperature (Q_bar = 0).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

T_s = T_BP; %initial guess for surface temperature
for i = 1:3
T_film = T_s + (T_inf-T_s)/3; % Use one-third rule for initial guess.
omega_film = 0;

%evaluate properties
[cp_A_film, cv_A_film] = F_cp_data(species_A, T_film);
[cp_B_film, cv_B_film] = F_cp_data(species_B, T_film);
[Gamma_film, lambda_film, ~] = F_TransportProperties(species_A,species_B,T_film,omega_film);


T_ex = T_inf/T_BP;
Ja = cp_A_film*T_BP/L;
gamma = cp_A_film/cv_A_film;
cp_bar = cp_A_film/cp_B_film;
Le = lambda_film/(cp_B_film*Gamma_film);
epsilon = M_A/M_B;
Phi = 1-omega_inf;

%Based on fluid properties, calculate Spalding numbers
[BM_guess, BT_guess] = F_SpaldingNumbers(Ja, T_ex, Phi, epsilon, Le, gamma, cp_bar);
T_s = T_inf-BT_guess*L/cp_A_film;
omega_s = 1-(1-omega_inf)/(BM_guess+1);

end

%% initialise fields
% initial guess for mass fraction field
omega_n(1,1:N) = omega_inf-(omega_inf-omega_s)./r_n;
omega_b(1,1) = omega_s;
omega_b(1,N+1) = omega_inf;
omega_b(1,2:N) = omega_n(1,1:N-1)+(omega_n(1,2:N)-omega_n(1,1:N-1)).*(r_b(2:N)-r_n(1:N-1))./(r_n(2:N)-r_n(1:N-1));
% initial guess for the temperature field
T_n(1,1:N) = T_inf-(T_inf-T_s)./r_n;
T_b(1,1) = T_s;
T_b(1,N+1) = T_inf;
T_b(1,2:N) = T_n(1,1:N-1)+(T_n(1,2:N)-T_n(1,1:N-1)).*(r_b(2:N)-r_n(1:N-1))./(r_n(2:N)-r_n(1:N-1));
% initial guess for fluid property fields
Gamma_b = Gamma_film*ones(1,N+1);
lambda_b = lambda_film*ones(1,N+1);
cp_A_b = F_cp_data(species_A, T_film)*ones(1,N+1);
%initial guess for evaporative mass flow rate
m_dot_FullVarProp = r_b(1)*Gamma_film*log((1-omega_inf)/(1-omega_s));
