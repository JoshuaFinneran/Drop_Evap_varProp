%Copyright, Joshua Finneran, 2021.

%Please cite as: Finneran J, "On the Evaluation of Transport Properties 
%for Droplet Evaporation Problems", International Journal of Heat and Mass
%Transfer, 2021.

%_________________________________________________________________________


% This creates an initial guess for the mass fraction and temperature
% fields. This is based on assuming constant fluid properties evaluated
% using the 1/3 rule.

% The surface temperature T_s is specified

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
omega_s = (M_B/M_A*(exp(L/R_A*(1/T_s - 1/T_BP))-1)+1)^(-1); %Clausius-Clapeyron 

T_film = T_s + (T_inf-T_s)/3; % Use one-third rule for initial guess.
omega_film = 0;
%evaluate properties
[cp_A_film, cv_A_film] = F_cp_data(species_A, T_film);
[cp_B_film, cv_B_film] = F_cp_data(species_B, T_film);
[Gamma_film, lambda_film, ~] = F_TransportProperties(species_A,species_B,T_film,omega_film);

%% initialise fields
% initial guess for mass fraction field
omega_n(1,1:N) = omega_inf-(omega_inf-omega_s)./r_n;
omega_b(1,1) = omega_s;
omega_b(1,N+1) = omega_inf;
omega_b(1,2:N) = omega_n(1,1:N-1)+(omega_n(1,2:N)-omega_n(1,1:N-1)).*(r_b(2:N)-r_n(1:N-1))./(r_n(2:N)-r_n(1:N-1));
% initial guess for the temperature field
T_n(1,1:N) = T_inf-(T_inf-T_s)./r_n;
T_b(1,1) = T_s;
T_b(1,N+1) = T_inf;
T_b(1,2:N) = T_n(1,1:N-1)+(T_n(1,2:N)-T_n(1,1:N-1)).*(r_b(2:N)-r_n(1:N-1))./(r_n(2:N)-r_n(1:N-1));
% initial guess for fluid property fields
Gamma_b = Gamma_film*ones(1,N+1);
lambda_b = lambda_film*ones(1,N+1);
cp_A_b = F_cp_data(species_A, T_film)*ones(1,N+1);
%initial guess for evaporative mass flow rate
m_dot_FullVarProp = r_b(1)*Gamma_film*log((1-omega_inf)/(1-omega_s));
