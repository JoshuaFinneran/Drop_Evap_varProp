%% figure geometry inputs
border = 2; 
space = 0.6;
border_vert = 1.05;

FontSize=8;
linewidth = 1;
markersize = 3;

fig_width = 10;
ax_width = 5;
fig_height = 19;
aspect=2;
aspect2=1.2;

%% create figure and axes
figure1 = figure;
set(figure1,'units','centimeters')
set(figure1,'position',[1,1,fig_width  , fig_height])
set(figure1,'color',[1 1 1])

axes1 = axes('Parent',figure1);
hold on
box on
set(axes1,'units','centimeters')
set(axes1,'position',[1*border,2*border_vert+space+ax_width/aspect2,ax_width,ax_width/aspect])
axes1.XGrid='on';
axes1.YGrid='on';
axes1.GridColor=[1 1 1]*0.7;
axes1.GridAlpha=0.4;
axes1.MinorGridAlpha=0.15;
axes1.MinorGridColor=axes1.GridColor;
axes1.MinorGridLineStyle='-';

axes2 = axes('Parent',figure1);
hold on
box on
set(axes2,'units','centimeters')
set(axes2,'position',[1*border,2*border_vert+space+ax_width/aspect2+space+ax_width/aspect,ax_width,ax_width/aspect])
axes2.XGrid='on';
axes2.YGrid='on';
axes2.GridColor=[1 1 1]*0.7;
axes2.GridAlpha=0.4;
axes2.MinorGridAlpha=0.15;
axes2.MinorGridColor=axes2.GridColor;
axes2.MinorGridLineStyle='-';

axes3 = axes('Parent',figure1);
hold on
box on
set(axes3,'units','centimeters')
set(axes3,'position',[1*border,2*border_vert+space+ax_width/aspect2+2*space+2*ax_width/aspect,ax_width,ax_width/aspect])
axes3.XGrid='on';
axes3.YGrid='on';
axes3.GridColor=[1 1 1]*0.7;
axes3.GridAlpha=0.4;
axes3.MinorGridAlpha=0.15;
axes3.MinorGridColor=axes3.GridColor;
axes3.MinorGridLineStyle='-';


axes4 = axes('Parent',figure1);
hold on
box on
set(axes4,'units','centimeters')
set(axes4,'position',[1*border,2*border_vert+space+ax_width/aspect2+3*space+3*ax_width/aspect,ax_width,ax_width/aspect])
axes4.XGrid='on';
axes4.YGrid='on';
axes4.GridColor=[1 1 1]*0.7;
axes4.GridAlpha=0.4;
axes4.MinorGridAlpha=0.15;
axes4.MinorGridColor=axes4.GridColor;
axes4.MinorGridLineStyle='-';

axes5 = axes('Parent',figure1);
hold on
box on
set(axes5,'units','centimeters')
set(axes5,'position',[1*border,1*border_vert,ax_width,ax_width/aspect2])
axes5.XGrid='on';
axes5.YGrid='on';
axes5.GridColor=[1 1 1]*0.7;
axes5.GridAlpha=0.4;
axes5.MinorGridAlpha=0.15;
axes5.MinorGridColor=axes5.GridColor;
axes5.MinorGridLineStyle='-';

%% plot data

% Results_fields = [1.r ; ...
%     2.T_FullVarProp ; 3.omega_FullVarProp ; 4.Gamma_FullVarProp ; 5.lambda_FullVarProp ; ...
%     6.T_ConstProp_eq_FullVarProp ; 7.omega_ConstProp_eq_FullVarProp ; 8.Gamma_ConstProp_eq_FullVarProp ; 9.lambda_ConstProp_eq_FullVarProp ; ...
%     10.T_RootTProp_eq_FullVarProp ; 11.omega_RootTProp_eq_FullVarProp ; 12.Gamma_RootTProp_eq_FullVarProp ; 13.lambda_RootTProp_eq_FullVarProp ];

style_vec = {'b-.','r--','k-'};

plot(1./Results_fields(1,:),Results_fields(2,:),style_vec{3},'Parent',axes4,'LineWidth',linewidth)
plot(1./Results_fields(1,:),Results_fields(6,:),style_vec{1},'Parent',axes4,'LineWidth',linewidth)
plot(1./Results_fields(1,:),Results_fields(10,:),style_vec{2},'Parent',axes4,'LineWidth',linewidth)

plot(1./Results_fields(1,:),Results_fields(3,:),style_vec{3},'Parent',axes3,'LineWidth',linewidth)
plot(1./Results_fields(1,:),Results_fields(7,:),style_vec{1},'Parent',axes3,'LineWidth',linewidth)
plot(1./Results_fields(1,:),Results_fields(11,:),style_vec{2},'Parent',axes3,'LineWidth',linewidth)

plot(1./Results_fields(1,:),Results_fields(5,:)*1e3,style_vec{3},'Parent',axes2,'LineWidth',linewidth)
plot(1./Results_fields(1,:),Results_fields(9,:)*1e3,style_vec{1},'Parent',axes2,'LineWidth',linewidth)
plot(1./Results_fields(1,:),Results_fields(13,:)*1e3,style_vec{2},'Parent',axes2,'LineWidth',linewidth)

plot(1./Results_fields(1,:),Results_fields(4,:)*1e6,style_vec{3},'Parent',axes1,'LineWidth',linewidth)
plot(1./Results_fields(1,:),Results_fields(8,:)*1e6,style_vec{1},'Parent',axes1,'LineWidth',linewidth)
plot(1./Results_fields(1,:),Results_fields(12,:)*1e6,style_vec{2},'Parent',axes1,'LineWidth',linewidth)


% Results_AfilmSweep = [1.A_film_vec; 2.j_ev_a_Afilmsweep_vec ; 3.Q_bar_Afilmsweep_vec ; 4.T_s_Afilmsweep_vec;
                      % 5.omega_s_Afilmsweep_vec;  6.Gamma_Afilmsweep_vec ; 7.lambda_Afilmsweep_vec];

plot(Results_AfilmSweep(1,:),Results_AfilmSweep(2,:)*1e6,'k-','Parent',axes5,'LineWidth',linewidth)

%precise A
plot([0 A_film_precise A_film_precise],[j_ev_a_FullVarProp  j_ev_a_FullVarProp 0]*10^6,'k--','Parent',axes5,'LineWidth',linewidth/2)

% theoretical A
plot([0 A_film_theory A_film_theory], [j_ev_a_theory  j_ev_a_theory 0]*10^6,'k:','Parent',axes5,'LineWidth',linewidth/2)

%1/3 rule
plot([0 1/3 1/3], [j_ev_a_Afilm_onethird  j_ev_a_Afilm_onethird 0]*10^6,'k-.','Parent',axes5,'LineWidth',linewidth/2)

%% labels
set(axes1,'FontSize',FontSize)
set(axes2,'FontSize',FontSize)
set(axes3,'FontSize',FontSize)
set(axes4,'FontSize',FontSize)
set(axes5,'FontSize',FontSize)


axes2.XTickLabel={};
axes3.XTickLabel={};
axes4.XTickLabel={};

axes5.XLim=[0 0.5];

xtickformat(axes1,'%.1f')
xlabel(axes1,'Inverse radial distance, $a/r$','interpreter','latex')
ylabel(axes1,'$\Gamma$, $\times 10^{-6}$ kg m$^{-1}$ s$^{-1}$','interpreter','latex')
ylabel(axes2,'$\lambda$, $\times 10^{-3}$ W m$^{-1}$ K$^{-1}$','interpreter','latex')
ylabel(axes3,'$\omega$, -','interpreter','latex')
ylabel(axes4,'$T$, K','interpreter','latex')

xlabel(axes5,'Film weighting coefficient $A_f$, -','interpreter','latex')
ylabel(axes5,{'Evaporation rate' ; '$K_{cst}(A_f)$, $\times 10^{-6}$ kg m$^{-1}$ s$^{-1}$'},'interpreter','latex')

Leg1 = legend(axes5,'$K_{cst}(A_f)$','$[A_f]_{act}$','$[A_f]_{theo}$','$1/3$');
Leg1.Interpreter = 'latex';
Leg1.Units='centimeters';
Leg1.Position = [7.2477    3.8583    2.3092    1.3647];

