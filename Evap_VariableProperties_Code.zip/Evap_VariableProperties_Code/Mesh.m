%% define numerical mesh
num_nodes = 4000; %define number of node boundaries
r_min = 1; %radius of droplet surface
r_max = 10^5; %maxium radius
r_b = 10.^linspace(log10(r_min),log10(r_max),num_nodes); %radius of element boundaries
N = length(r_b)-1;  %number of nodes
r_n = 0.5*(r_b(1:N)+r_b(2:N+1)); %radial position of nodes

r_b = a_drop*r_b;
r_n = a_drop*r_n;
