function [Gamma_AB, lambda_AB, mew_AB]=F_TransportProperties(species_A,species_B,T,omega_A)

% for given binary mixture of fluids, this function returns the mixture
% transport properties.

% Reference: R.B. Bird, W.E. Stewart, E.N. Lightfoot, "Transport Phenomena", 2nd Edition,
% John Wiely and Sons, Inc, 2002.

% species_A and species B are strings contaning the fluid names
% T is the temperature in K
% omega_A is the mass fraction of species A
% Gamma_AB is the mixture mass diffusivity in kg m^-1 s^-1
% lambda_AB is the mixture thermal conductivity in W m^-1 K^-1
% mew_AB is the mixture dynamic viscosity in kg m^-1 s^-1

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

species = ["air" "nitrogen" "oxygen" "hydrogen" "methane" "carbondioxide" "carbonmonoxide" "octane" "butane" "ethane" "heptane"]';
A_idx = find(species_A == species);
B_idx = find(species_B == species);

R_u = 8.3145e3;
% table of Lennard-Jones parameters
% from Bird et. al. (2002), Table E.1, p864
%       %M    %sigma %e/k 
data = [28.964 3.617 97; %air
        28.013 3.667 99.8; %nitrogen
        31.999 3.433 113; %oxygen
        2.016 2.915 38; %hydrogen
        16.04 3.780 154; %methane
        44.010 3.996 190; %CO2
        28.01 3.59 110; %CO
        114.23 7.035 361; %octane
        58.12 5.604 304; %butane
        30.07 4.388 232; %ethane
        100.2 6.663 352]; %heptane
        
M_A = data(A_idx,1);
sigma_A = data(A_idx,2);
e_k_A = data(A_idx,3);
R_A = R_u/M_A;

M_B = data(B_idx,1);
sigma_B = data(B_idx,2);
e_k_B = data(B_idx,3);
R_B = R_u/M_B;

sigma_AB = 0.5*(sigma_A+sigma_B);
e_k_AB = (e_k_A*e_k_B)^0.5;
R_AB = R_B*(1-omega_A)+R_A*omega_A;


% Collision integral data, Bird et. al. (2002), Table E.2
T_e_k = [0.3:0.05:2 2.1:0.1:2.6 2.7:0.1:5 6:10 12:2:20 25:5:40 50 70 100];
Omega_diff_dat = [2.649 2.468 2.314 2.182 2.066 1.965 1.877 1.799 1.729 1.667 1.612 1.562 1.517 1.477 1.44 ...
              1.406 1.375 1.347 1.32 1.296 1.274 1.253 1.234 1.216 1.199 1.183 1.168 1.154 1.141 1.128 ...
              1.117 1.105 1.095 1.085 1.075 1.058 1.042 1.027 1.013 1.0006 0.989 ...
              0.9782 0.9682 0.9588 0.9500 0.9418 0.9340 0.9267 0.9197 0.9131 0.9068 0.9008 0.8952 0.8897 0.8845 ...
              0.8796 0.8748 0.8703 0.8659 0.8617 0.8576 0.8537 0.8499 0.8463 0.8428 0.8129 0.7898 0.7711 0.7555 0.7422 ...
              0.7202 0.7025 0.6878 0.6751 0.6640 0.6414 0.6235 0.6088 0.5964 0.5763 0.5415 0.5180];
    
Omega_lambda_dat = [2.84 2.676 2.531 2.401 2.284 2.178 2.084 1.999 1.922 1.853 1.790 1.734 1.682 1.636 1.593 1.554 ...
                1.518 1.485 1.455 1.427 1.401 1.377 1.355 1.334 1.315 1.297 1.28 1.264 1.249 1.234 1.222 1.209 1.198 ...
                1.186 1.176 1.156 1.138 1.122 1.107 1.0933 1.0807 1.0691 1.0583 1.0482 1.0388 1.03 1.0217 1.0139 ...
                1.0066 0.9996 0.9931 0.9868 0.9809 0.9753 0.9699 0.9647 0.9598 0.9551 0.9506 0.9462 0.942 0.938...
                0.9341 0.9304 0.9268 0.8962 0.8727 0.8538 0.838 0.8244 ...
                0.8018 0.7836 0.7683 0.7552 0.7436 0.7198 0.7010 0.6854 0.6723 0.6510 0.6140 0.5887];


Omega_diff_AB = interp1(T_e_k,Omega_diff_dat,max([T/e_k_AB min(T_e_k)]));%T/e_k_AB);
Omega_lambda_A = interp1(T_e_k,Omega_lambda_dat,max([T/e_k_A min(T_e_k)]));%T/e_k_A);
Omega_lambda_B = interp1(T_e_k,Omega_lambda_dat,max([T/e_k_B min(T_e_k)]));%T/e_k_B);


%eq.17.3-12 Bird et. al. p526
Gamma_AB = 0.0018583*101325*1e-4*(1/M_A+1/M_B)^0.5*T^0.5/(sigma_AB^2*Omega_diff_AB*R_AB);

%eq1.4-14 Bird et. al. p26
mew_A = 2.6693e-6*(M_A*T)^0.5/(sigma_A^2*Omega_lambda_A);
mew_B = 2.6693e-6*(M_B*T)^0.5/(sigma_B^2*Omega_lambda_B);

M = [M_A M_B];
mew = [mew_A mew_B];
%eq1.4-16 in Bird et. al. p26
for i = 1:2
    for j=1:2
        phi(i,j) = 1/8^0.5*(1+M(i)/M(j))^-0.5*(1+(mew(i)/mew(j))^0.5*(M(j)/M(i))^0.25)^2;
    end
end
     

[cp_A, cv_A] = F_cp_data(species_A, T);
[cp_B, cv_B] = F_cp_data(species_B, T);


%eq9.3-15 Bird et. al. p276
lambda_A = (cp_A+5/4*R_A)*mew_A;
lambda_B = (cp_B+5/4*R_B)*mew_B;


m = [omega_A 1-omega_A];
lambda = [lambda_A lambda_B];
for i =1:2
    for j = 1:2
        tmp(i,j)=m(j)*phi(i,j);
    end
    mew_temp(i) = m(i)*mew(i)/(sum(tmp(i,:)));
    lambda_temp(i) = m(i)*lambda(i)/(sum(tmp(i,:)));
end
mew_AB = sum(mew_temp);
lambda_AB = sum(lambda_temp);

end

